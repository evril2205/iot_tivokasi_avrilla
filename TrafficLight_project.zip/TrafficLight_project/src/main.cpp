#include <Arduino.h>  

// Definisi pin untuk ketiga lampu
int lampu = 25;      // LED Hijau
int lampu2 = 33;     // LED Kuning
int lampu3 = 32;     // LED Merah

void setup() {
    Serial.begin(115200);  
    Serial.println("ESP32 Traffic Light");
    pinMode(lampu, OUTPUT);
    pinMode(lampu2, OUTPUT);
    pinMode(lampu3, OUTPUT);
}

void loop() {
    // Lampu Merah menyala
    digitalWrite(lampu3, HIGH);
    digitalWrite(lampu2, LOW);
    digitalWrite(lampu, LOW);
    Serial.println("Lampu Merah ON");
    delay(3000);  // Tunggu 5 detik

    // Lampu Kuning menyala
    digitalWrite(lampu3, LOW);
    digitalWrite(lampu2, HIGH);
    digitalWrite(lampu, LOW);
    Serial.println("Lampu Kuning ON");
    delay(3000);  // Tunggu 2 detik

    // Lampu Hijau menyala
    digitalWrite(lampu3, LOW);
    digitalWrite(lampu2, LOW);
    digitalWrite(lampu, HIGH);
    Serial.println("Lampu Hijau ON");
    delay(5000);  // Tunggu 5 detik
}
